﻿using DotnetCoding.Core.Models;
using DotnetCoding.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace DotnetCoding.Controllers
{
    /// <summary>
    /// Products API Controller
    /// </summary>
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        public readonly IProductService _productService;
        public readonly IProductApprovalService _productApprovalService;

        /// <summary>
        /// Products API Controller Constuctor
        /// </summary>
        /// <param name="productService"></param>
        /// <param name="productApprovalService"></param>
        public ProductsController(IProductService productService, IProductApprovalService productApprovalService)
        {
            _productService = productService;
            _productApprovalService = productApprovalService;
        }

        /// <summary>
        /// Get the list of product
        /// Only active products should be listed in the page, the order should be latest first.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public async Task<IActionResult> GetProductList()
        {
            var productDetailsList = await _productService.GetAllActiveProducts();
            if (productDetailsList == null)
            {
                return NotFound();
            }
            return Ok(productDetailsList);
        }

        /// <summary>
        /// Get Product By productId
        /// </summary>
        /// <param name="productId"></param>
        /// <returns></returns>
        [HttpGet("{productId}")]
        public async Task<IActionResult> GetProductById(int productId)
        {
            if (productId < 1)
                return BadRequest();
            var product = await _productService.GetProductById(productId);
            if (product == null)
                return NotFound();
            return Ok(product);
        }

        /// <summary>
        /// Create Product 
        /// it should follow certain business logic as follows
        /// 1.Product creation is not allowed when its price is more than 10000 dollars
        /// 2.Any product should be pushed to approval queue if its price is more than 5000 dollars at the time of creation
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> CreateProduct(ProductDetails product)
        {
            product.Id = 0;
            product.ProductStatus = "Create";
            product.PostedDate = DateTime.Now;
            // Check for product creation is not allowed when its price is more than 10000 dollars
            if (product.ProductPrice > 10000)
            {
                return ValidationProblem("Product Price is more than 10000");
            }
            //Any product should be pushed to approval queue if its price is more than 5000 dollars at the time of creation
            else if (product.ProductPrice > 5000)
            {
                ProductApprovalRequests productApprovalRequests = new ProductApprovalRequests();
                productApprovalRequests.ProductJson = JsonConvert.SerializeObject(product);
                productApprovalRequests.Reason = "Product Price is more than 5000";
                productApprovalRequests.RequestedDate = DateTime.Now;

                //Moving product to the product approval queue
                if ((await _productApprovalService.CreateProductApprovalRequest(productApprovalRequests)) > 0)
                {
                    return Ok("Product Price is more than 5000, moved to approval queue");
                }
                else
                {
                    return BadRequest("Something went wrong while creating product, please check logs for more detail");
                }
            }
            else
            {
                //Create the product if it meets the business logic criteria
                if ((await _productService.CreateProduct(product)) > 0)
                {
                    return Ok();
                }
                else
                {
                    return BadRequest("Something went wrong while creating product, please check logs for more detail");
                }
            }
        }

        /// <summary>
        /// Update the Product
        /// it should follow certain business logic as follows
        /// 1.Any product should be pushed to approval queue if its price is more than 5000 dollars at the time of updating
        /// 2.Any product should be pushed to approval queue if its price is more than 50% of its previous price
        /// </summary>
        /// <param name="productData"></param>
        /// <returns></returns>
        [HttpPut]
        public async Task<IActionResult> UpdateProduct(ProductDetails productData)
        {
            if (productData == null || productData.Id == 0)
                return BadRequest();

            var product = await _productService.GetProductById(productData.Id);
            if (product == null)
                return NotFound();
            //Get previous price
            int previousPrice = product.ProductPrice;
            //Get previous price 50%
            int previousPrice50Percentage = product.ProductPrice / 2;
            product.ProductName = productData.ProductName;
            product.ProductDescription = productData.ProductDescription;
            product.ProductPrice = productData.ProductPrice;
            product.ProductStatus = "Update";
            product.ModifiedDate = DateTime.Now;
            /// Check for product should be pushed to approval queue if its price is more than 5000 dollars at the time of updating
            /// Check for product should be pushed to approval queue if its price is more than 50% of its previous price
            if (product.ProductPrice > 5000 || (previousPrice + previousPrice50Percentage) < product.ProductPrice)
            {
                ProductApprovalRequests productApprovalRequests = new ProductApprovalRequests();
                productApprovalRequests.ProductJson = JsonConvert.SerializeObject(product);
                if (product.ProductPrice > 5000)
                {
                    productApprovalRequests.Reason = "Product Price is more than 5000";
                }
                else
                {
                    productApprovalRequests.Reason = "Product Price price is more than 50% of its previous price";
                }
                productApprovalRequests.RequestedDate = DateTime.Now;
                //Moving product to the product approval queue
                if ((await _productApprovalService.CreateProductApprovalRequest(productApprovalRequests)) > 0)
                {
                    return Ok("Product Price is more than 5000, moved to approval queue");
                }
                else
                {
                    return BadRequest("Something went wrong while updating product, please check logs for more detail");
                }
            }
            else
            {
                //Update the product if it meets the business logic criteria
                if ((await _productService.UpdateProduct(product)) > 0)
                {
                    return Ok();
                }
                else
                {
                    return BadRequest("Something went wrong while updating product, please check logs for more detail");
                }
            }
        }

        /// <summary>
        /// Delete Product
        /// 1.Product should be pushed to approval queue in case delete. 
        /// </summary>
        /// <param name="productId"></param>
        /// <returns></returns>
        [HttpDelete("{productId}")]
        public async Task<IActionResult> DeleteProduct(int productId)
        {
            if (productId < 1)
                return BadRequest();
            var product = await _productService.GetProductById(productId);
            if (product == null)
                return NotFound();
            ProductApprovalRequests productApprovalRequests = new ProductApprovalRequests();
            productApprovalRequests.ProductJson = JsonConvert.SerializeObject(product);
            productApprovalRequests.Reason = "Delete the Product";
            productApprovalRequests.RequestedDate = DateTime.Now;

            //Moving product to the product approval queue
            if ((await _productApprovalService.CreateProductApprovalRequest(productApprovalRequests)) > 0)
            {
                return Ok("Product is moved to approval queue");
            }
            else
            {
                return BadRequest("Something went wrong while creating product, please check logs for more detail");
            }
        }

        /// <summary>
        /// Search Product
        /// Products can be searched using Product name, Price range and posted date range
        /// </summary>
        /// <param name="productName">Enter Product Name</param>
        /// <param name="fromPrice">Enter From Price</param>
        /// <param name="toPrice">Enter To Price</param>
        /// <param name="fromDate">Enter From Date in dd-MMM-yyy format</param>
        /// <param name="toDate">Enter To Date in dd-MMM-yyy format</param>
        /// <returns></returns>
        [HttpGet]
        //[Route("SearchProduct")]
        public async Task<IActionResult> SearchProduct(string productName, int? fromPrice, int? toPrice, DateTime? fromDate, DateTime? toDate)
        {
            var productDetailsList = await _productService.SearchProducts(productName, fromPrice, toPrice, fromDate, toDate);
            return Ok(productDetailsList);
        }
    }
}
