﻿using DotnetCoding.Core.Models;
using DotnetCoding.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace DotnetCoding.Controllers
{
    /// <summary>
    /// Product Approval Controller
    /// </summary>
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class ProductApprovalController : ControllerBase
    {
        public readonly IProductService _productService;
        public readonly IProductApprovalService _productApprovalService;

        /// <summary>
        /// Product Approval Controller Constructor
        /// </summary>
        /// <param name="productService"></param>
        /// <param name="productApprovalService"></param>
        public ProductApprovalController(IProductService productService, IProductApprovalService productApprovalService)
        {
            _productService = productService;
            _productApprovalService = productApprovalService;
        }

        /// <summary>
        /// Get All Pending Product Approval Requests
        /// User should be able to see all the products in approval queue along with product name, request reason and request date.The order should be based on request date where user can view first requested item first.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public async Task<IActionResult> GetAllPendingProductApprovalRequests()
        {
            var productApprovalRequests = await _productApprovalService.GetAllPendingProductApprovalRequests();
            if (productApprovalRequests == null)
            {
                return NotFound();
            }
            return Ok(productApprovalRequests);
        }

        /// <summary>
        /// Approve Or Reject
        /// Based on user action parameter perform Reject/Create/Update/Delete product changes
        /// 1. Product will be updated with new state (Create, Update, Delete) which should be reflected immediately in the product list and disappeared from the queue after the approval.
        /// 2. Product will remain in its original state in case of rejection in the queue and will be disappeared from the queue.
        /// </summary>
        /// <param name="productApprovalId"></param>
        /// <param name="action">Please enter only "Approved" or "Rejected"</param>
        /// <param name="actionTakenBy">Specify the user name who took the action</param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> ApproveOrReject(int productApprovalId, string action, string actionTakenBy)
        {
            if (productApprovalId < 1)
                return BadRequest();
            var productApprovalRequest = await _productApprovalService.GetProductApprovalRequestById(productApprovalId);
            if (productApprovalRequest == null)
                return NotFound();
            //User rejected the request
            if (action == "Rejected")
            {
                // Product will remain in its original state in case of rejection in the queue and will be disappeared from the queue. 
                productApprovalRequest.Action = action;
                productApprovalRequest.ActionTakenDate = DateTime.Now;
                productApprovalRequest.ActionTakenBy = actionTakenBy;
                //Update the request to rejected and it will no longer display in the pending approval list
                if ((await _productApprovalService.UpdateProductApprovalRequest(productApprovalRequest)) > 0)
                {
                    return Ok();
                }
                else
                {
                    return BadRequest("Something went wrong while rejecting the request, please check logs for more detail");
                }
            }
            //User approved the request
            else if (action == "Approved")
            {
                ProductDetails product = JsonConvert.DeserializeObject<ProductDetails>(productApprovalRequest.ProductJson);
                // Reason for approval request is delete product
                if (productApprovalRequest.Reason == "Delete the Product")
                {
                    product.ProductStatus = "Delete";
                    product.ModifiedDate = DateTime.Now;
                    await _productService.UpdateProduct(product);
                }
                // Reason for approval request is Product Price is more than 5000
                // Reason for approval request is Product Price price is more than 50% of its previous price
                else if (productApprovalRequest.Reason == "Product Price is more than 5000"
                    || productApprovalRequest.Reason == "Product Price price is more than 50% of its previous price")
                {
                    //if the product already exist update the product
                    if (product.Id != 0)
                    {
                        product.ProductStatus = "Update";
                        product.ModifiedDate = DateTime.Now;
                        await _productService.UpdateProduct(product);
                    }
                    //if the product doesnt exist create the new product
                    else
                    {
                        product.ProductStatus = "Create";
                        product.PostedDate = DateTime.Now;
                        product.IsActive = true;
                        await _productService.CreateProduct(product);
                    }
                }
                else if (string.IsNullOrWhiteSpace(productApprovalRequest.Reason))
                {
                    return BadRequest("Something went wrong while approving the request, please check logs for more detail");
                }
                productApprovalRequest.Action = action;
                productApprovalRequest.ActionTakenDate = DateTime.Now;
                productApprovalRequest.ActionTakenBy = actionTakenBy;
                //Update the request to approved and it will no longer display in the pending approval list
                if ((await _productApprovalService.UpdateProductApprovalRequest(productApprovalRequest)) > 0)
                {
                    return Ok();
                }
                else
                {
                    return BadRequest("Something went wrong while rejecting the request, please check logs for more detail");
                }
            }
            else
            {
                return BadRequest("Something went wrong while approving/rejecting the request, please check logs for more detail");
            }
        }
    }
}
