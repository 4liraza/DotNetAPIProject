USE [ProductInventory]
GO
/****** Object:  Table [dbo].[ProductApprovalRequest]    Script Date: 9/21/2023 4:13:43 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ProductApprovalRequest](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ProductJson] [nvarchar](max) NULL,
	[Reason] [varchar](500) NOT NULL,
	[RequestedDate] [datetime] NOT NULL,
	[Action] [varchar](50) NULL,
	[ActionTakenDate] [datetime] NULL,
	[ActionTakenBy] [varchar](50) NULL,
 CONSTRAINT [PK_ProductApprovalRequest] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ProductDetail]    Script Date: 9/21/2023 4:13:43 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ProductDetail](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ProductName] [nvarchar](100) NOT NULL,
	[ProductDescription] [nvarchar](max) NULL,
	[ProductPrice] [int] NOT NULL,
	[ProductStatus] [varchar](10) NOT NULL,
	[PostedDate] [datetime] NOT NULL,
	[IsActive] [bit] NOT NULL,
	[ModifiedDate] [datetime] NULL,
 CONSTRAINT [PK_ProductDetail] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[ProductDetail] ADD  CONSTRAINT [DF_ProductDetail_IsActive]  DEFAULT ((0)) FOR [IsActive]
GO
