﻿using DotnetCoding.Core.Models;

namespace DotnetCoding.Services.Interfaces
{
    /// <summary>
    /// Product Service Interface
    /// </summary>
    public interface IProductService
    {
        /// <summary>
        /// Get All Active Products
        /// Only active products should be listed in the page, the order should be latest first.
        /// </summary>
        /// <returns></returns>
        Task<IEnumerable<ProductDetails>> GetAllActiveProducts();

        /// <summary>
        /// Get Product By productId
        /// </summary>
        /// <param name="productId"></param>
        /// <returns></returns>
        Task<ProductDetails> GetProductById(int productId);

        /// <summary>
        /// Create Product
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        Task<int> CreateProduct(ProductDetails product);

        /// <summary>
        /// Update the Product
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        Task<int> UpdateProduct(ProductDetails product);

        /// <summary>
        /// Delete the Product
        /// </summary>
        /// <param name="productId"></param>
        /// <returns></returns>
        Task<int> DeleteProduct(int productId);

        /// <summary>
        /// Search Products
        /// </summary>
        /// <param name="productName"></param>
        /// <param name="fromPrice"></param>
        /// <param name="toPrice"></param>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <returns></returns>
        Task<IEnumerable<ProductDetails>> SearchProducts(string productName, int? fromPrice, int? toPrice, DateTime? fromDate, DateTime? toDate);
    }
}
