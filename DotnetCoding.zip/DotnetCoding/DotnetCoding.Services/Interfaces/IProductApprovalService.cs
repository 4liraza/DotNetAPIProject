﻿using DotnetCoding.Core.Models;

namespace DotnetCoding.Services.Interfaces
{
    /// <summary>
    /// Product Approval Service Interface
    /// </summary>
    public interface IProductApprovalService
    {
        /// <summary>
        /// Get All Pending Product Approval Requests
        /// </summary>
        /// <returns></returns>
        Task<IEnumerable<ProductApprovalRequests>> GetAllPendingProductApprovalRequests();

        /// <summary>
        /// Get Product Approval Request By productApprovalRequestId
        /// </summary>
        /// <param name="productApprovalRequestId"></param>
        /// <returns></returns>
        Task<ProductApprovalRequests> GetProductApprovalRequestById(int productApprovalRequestId);

        /// <summary>
        /// Create Product Approval Request
        /// </summary>
        /// <param name="productApprovalRequest"></param>
        /// <returns></returns>
        Task<int> CreateProductApprovalRequest(ProductApprovalRequests productApprovalRequest);

        /// <summary>
        /// Update Product Approval Request
        /// </summary>
        /// <param name="productApprovalRequest"></param>
        /// <returns></returns>
        Task<int> UpdateProductApprovalRequest(ProductApprovalRequests productApprovalRequest);
    }
}
