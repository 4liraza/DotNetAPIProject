﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DotnetCoding.Core.Interfaces;
using DotnetCoding.Core.Models;
using DotnetCoding.Services.Interfaces;

namespace DotnetCoding.Services
{
    /// <summary>
    /// Product Service
    /// </summary>
    public class ProductService : IProductService
    {
        public IUnitOfWork _unitOfWork;

        /// <summary>
        /// Product Service Constructor
        /// </summary>
        /// <param name="unitOfWork"></param>
        public ProductService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        /// <summary>
        /// Get All Active Products
        /// Only active products should be listed in the page, the order should be latest first.
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<ProductDetails>> GetAllActiveProducts()
        {
            var productDetailsList = await _unitOfWork.Products.GetAllActiveProducts();
            return productDetailsList;
        }

        /// <summary>
        /// Search Products
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<ProductDetails>> SearchProducts(string productName, int? fromPrice, int? toPrice, DateTime? fromDate, DateTime? toDate)
        {
            var productDetailsList = _unitOfWork.Products.GetAll().Where(p=> (string.IsNullOrWhiteSpace(productName) || (!string.IsNullOrWhiteSpace(productName) && p.ProductName.Contains(productName))) 
            && ((!fromPrice.HasValue || fromPrice.Value < 1) || (p.ProductPrice >= fromPrice.Value))
            && ((!toPrice.HasValue || toPrice.Value < 1) || (p.ProductPrice <= toPrice.Value))
            && ((!fromDate.HasValue) || (p.PostedDate >= fromDate.Value))
            && ((!toDate.HasValue) || (p.PostedDate <= toDate.Value))).ToList();
            return productDetailsList;
        }

        /// <summary>
        /// Get Product by productId
        /// </summary>
        /// <returns></returns>
        public async Task<ProductDetails> GetProductById(int productId)
        {
            var product = await _unitOfWork.Products.GetById(productId);
            return product;
        }


        /// <summary>
        /// Create Product
        /// </summary>
        /// <returns></returns>
        public async Task<int> CreateProduct(ProductDetails product)
        {
            return await _unitOfWork.Products.Create(product);
        }


        /// <summary>
        /// Update Product
        /// </summary>
        /// <returns></returns>
        public async Task<int> UpdateProduct(ProductDetails product)
        {
            return await _unitOfWork.Products.Update(product.Id, product);
        }

        /// <summary>
        /// Delete Product
        /// </summary>
        /// <returns></returns>
        public async Task<int> DeleteProduct(int productId)
        {
            return await _unitOfWork.Products.Delete(productId);
        }

    }
}
