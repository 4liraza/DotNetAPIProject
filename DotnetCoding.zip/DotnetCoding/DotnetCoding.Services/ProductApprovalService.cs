﻿using DotnetCoding.Core.Interfaces;
using DotnetCoding.Core.Models;
using DotnetCoding.Services.Interfaces;

namespace DotnetCoding.Services
{
    /// <summary>
    /// Product Approval Service
    /// </summary>
    public class ProductApprovalService : IProductApprovalService
    {
        public IUnitOfWork _unitOfWork;

        /// <summary>
        /// Product Approval Service Constructor
        /// </summary>
        /// <param name="unitOfWork"></param>
        public ProductApprovalService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        /// <summary>
        /// Get All Active Product Approval Requests
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<ProductApprovalRequests>> GetAllPendingProductApprovalRequests()
        {
            var productApprovalRequests = await _unitOfWork.ProductApprovals.GetAllPendingProductApprovalRequests();
            return productApprovalRequests;
        }

        /// <summary>
        /// Get Product Approval Request by productApprovalRequestId
        /// </summary>
        /// <returns></returns>
        public async Task<ProductApprovalRequests> GetProductApprovalRequestById(int productApprovalRequestId)
        {
            var productApprovalRequest = await _unitOfWork.ProductApprovals.GetById(productApprovalRequestId);
            return productApprovalRequest;
        }


        /// <summary>
        /// Create Product Approval Request
        /// </summary>
        /// <returns></returns>
        public async Task<int> CreateProductApprovalRequest(ProductApprovalRequests productApprovalRequest)
        {
            return await _unitOfWork.ProductApprovals.Create(productApprovalRequest);
        }


        /// <summary>
        /// Update Product Approval Request
        /// </summary>
        /// <returns></returns>
        public async Task<int> UpdateProductApprovalRequest(ProductApprovalRequests productApprovalRequest)
        {
            return await _unitOfWork.ProductApprovals.Update(productApprovalRequest.Id, productApprovalRequest);
        }
    }
}
