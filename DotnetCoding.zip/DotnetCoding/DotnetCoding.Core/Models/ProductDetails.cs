﻿

using DotnetCoding.Core.Interfaces;
using System.ComponentModel.DataAnnotations.Schema;

namespace DotnetCoding.Core.Models
{
    [Table("ProductDetail")]
    public class ProductDetails : IEntity
    {
        public int Id { get; set; }
        public string ProductName { get; set; }
        public string ProductDescription { get; set; }
        public int ProductPrice { get; set; }
        public string ProductStatus { get; set; }
        public DateTime PostedDate { get; set; }
        public bool IsActive { get; set; }
        public DateTime? ModifiedDate { get; set; }
        
    }
}
