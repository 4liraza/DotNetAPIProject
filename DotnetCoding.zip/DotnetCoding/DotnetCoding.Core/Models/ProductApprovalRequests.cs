﻿

using DotnetCoding.Core.Interfaces;
using System.ComponentModel.DataAnnotations.Schema;

namespace DotnetCoding.Core.Models
{
    [Table("ProductApprovalRequest")]
    public class ProductApprovalRequests : IEntity
    {
        public int Id { get; set; }
        public string ProductJson { get; set; }
        public string Reason { get; set; }
        public DateTime RequestedDate { get; set; }
        public string? Action { get; set; }
        public DateTime? ActionTakenDate { get; set; }
        public string? ActionTakenBy { get; set; }
        
    }
}
