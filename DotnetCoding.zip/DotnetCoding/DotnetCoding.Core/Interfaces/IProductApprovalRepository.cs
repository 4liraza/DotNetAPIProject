﻿using DotnetCoding.Core.Models;

namespace DotnetCoding.Core.Interfaces
{
    public interface IProductApprovalRepository : IGenericRepository<ProductApprovalRequests>
    {
        /// <summary>
        /// Get All Pending Product Approval Requests
        /// </summary>
        /// <returns></returns>
        Task<IEnumerable<ProductApprovalRequests>> GetAllPendingProductApprovalRequests();
    }
}
