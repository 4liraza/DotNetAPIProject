﻿using DotnetCoding.Core.Models;

namespace DotnetCoding.Core.Interfaces
{
    public interface IProductRepository : IGenericRepository<ProductDetails>
    {
        /// <summary>
        /// Get All Active Products
        /// Only active products should be listed in the page, the order should be latest first.
        /// </summary>
        /// <returns></returns>
        Task<IEnumerable<ProductDetails>> GetAllActiveProducts();
    }
}
