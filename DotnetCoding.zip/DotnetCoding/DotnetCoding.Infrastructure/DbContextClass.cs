﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DotnetCoding.Core.Models;

namespace DotnetCoding.Infrastructure
{
    /// <summary>
    /// Db Context Class
    /// </summary>
    public class DbContextClass : DbContext
    {
        public DbContextClass(DbContextOptions<DbContextClass> contextOptions) : base(contextOptions)
        {

        }
        /// <summary>
        /// ProductDetail Table Entity
        /// </summary>
        public DbSet<ProductDetails> Products { get; set; }

        /// ProductApprovalRequest Table Entity
        public DbSet<ProductApprovalRequests> ProductApprovalRequests { get; set; }
    }
}
