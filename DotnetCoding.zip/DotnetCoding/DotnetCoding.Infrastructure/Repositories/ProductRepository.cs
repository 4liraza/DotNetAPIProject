﻿using DotnetCoding.Core.Interfaces;
using DotnetCoding.Core.Models;
using Microsoft.EntityFrameworkCore;

namespace DotnetCoding.Infrastructure.Repositories
{
    /// <summary>
    /// Product Repository
    /// </summary>
    public class ProductRepository : GenericRepository<ProductDetails>, IProductRepository
    {
        /// <summary>
        /// Product Repository Constructor
        /// </summary>
        /// <param name="dbContext"></param>
        public ProductRepository(DbContextClass dbContext) : base(dbContext)
        {

        }

        /// <summary>
        /// Get All Active Products
        /// Only active products should be listed in the page, the order should be latest first.
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<ProductDetails>> GetAllActiveProducts()
        {
            return await GetAll().Where(p => p.IsActive && p.ProductStatus != "Delete").OrderByDescending(p => p.PostedDate).ToListAsync();

        }
    }
}
