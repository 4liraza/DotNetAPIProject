﻿using DotnetCoding.Core.Interfaces;
using DotnetCoding.Core.Models;
using Microsoft.EntityFrameworkCore;

namespace DotnetCoding.Infrastructure.Repositories
{
    /// <summary>
    /// Product Approval Repository
    /// </summary>
    public class ProductApprovalRepository : GenericRepository<ProductApprovalRequests>, IProductApprovalRepository
    {
        /// <summary>
        /// Product Approval Repository Constructor
        /// </summary>
        /// <param name="dbContext"></param>
        public ProductApprovalRepository(DbContextClass dbContext) : base(dbContext)
        {

        }

        /// <summary>
        /// Get All Pending Product Approval Requests
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<ProductApprovalRequests>> GetAllPendingProductApprovalRequests()
        {
            //User should be able to see all the products in approval queue along with product name, 
            //request reason and request date.The order should be based on request date where user can
            //view first requested item first. 
            return await GetAll().Where(p => p.ActionTakenDate == null && p.Action == null).OrderBy(p => p.RequestedDate).ToListAsync();

        }
    }
}
